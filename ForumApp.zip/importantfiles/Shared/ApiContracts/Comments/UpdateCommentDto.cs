namespace ApiContracts.Comments;

public class UpdateCommentDto
{
    public required string Body { get; set; }
}
