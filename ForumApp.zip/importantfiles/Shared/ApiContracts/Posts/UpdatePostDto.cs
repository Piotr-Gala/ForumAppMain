namespace ApiContracts.Posts;

public class UpdatePostDto
{
    public required string Title { get; set; }
    public required string Body { get; set; }
}
